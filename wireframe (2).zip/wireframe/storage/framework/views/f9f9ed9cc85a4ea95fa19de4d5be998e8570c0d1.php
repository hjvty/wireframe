<?php $__env->startSection('cards'); ?>
<div class="card-body">
				<div class="row">
					<div class="col-md-2">
						<img src="<?php echo e(url('public/assets/Spark-Joy-at-Work.jpg')); ?>" alt="customer">
					</div>
					<div class="col-md-10">
						<div>
							<div class="row">
								<div class="col-md-4">

									<h4>Customer Name
                    </h4>
									<h4>Business Name
                    </h4>
								</div>
								<div class="cpl-md-8"> <a href="#">edit
                    </a>
									<a href="#">delete
                    </a>
								</div>
							</div>
							<p>Email : xyz@gmail.com Phone:-9455</p>
							<p>Location: gcg Last Update:23588</p>
						</div>
					</div>
				</div>
			</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('wel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\wireframe\resources\views/customers.blade.php ENDPATH**/ ?>