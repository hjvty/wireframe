<!DOCTYPE html>
<html lang="en">

<head>
	<title>Wireframe</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
	</script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
	</script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<style>
		.table td, .table th {
		    border-bottom: 1px solid #dee2e6;
		}
	</style>
</head>

<body style="background-color:#f1f1f1">
	<div class="container">
		<br>
		<div class="card mt-6">
			<div class="card-body">
				<div class="row">
					<div class="col-md-2">
						<img src="<?php echo e(url('/cap.png')); ?>" alt="customer">
					</div>
					<div class="col-md-10">
                    <a href="" class="float-right mb-3" data-toggle="modal" data-target="#custexampleModal"><i class="fa fa-plus-square" style="font-size:24px"></i></a>
						<div class="customer">

						</div>
					</div>
				</div>
			</div>
		</div>
		<br>
		<div class="row mt-4">
			<div class="col-md-8" style="">
				<div class="card-deck">
					<div class="card">
						<div class="card-body">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs">
								<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#followup">Follow Up</a>
								</li>
								<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#drive">Drive</a>
								</li>
							</ul>
							<!-- Tab panes -->
							<div class="tab-content">
								<div id="followup" class="container tab-pane active">
									<br>
									<div class="panel-body"> <a href="" class="btn btn-success float-right mb-3" data-toggle="modal" data-target="#exampleModal">Add</a>
										<table class="table table-hover">
											<tbody></tbody>
										</table>
									</div>
								</div>
								<div id="drive" class="container tab-pane fade">
									<br>
									<h3>Drive</h3>
									<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4" style="display: inline-grid;">
				<div class="card-deck">
					<div class="card">
						<div class="card-body">
							<h5>Add Comments</h5>
							<ul class="mt-5" id="addcom" style="list-style: none;">
								<!-- <li><h6>lknkj</h6><p>date:6/5/21
                            <a href="#" data-toggle="modal" data-target="#exampleModal">edit</a>
                            <a href="#">delete</a></p></li> -->
							</ul>
							<!-- <form id="Addfrom" name="userForm" class="ml-5"> -->
							<!-- <?php echo csrf_field(); ?> -->
							<input class="ml-5" type="text" name="comment" id="comment" required/> <span id="comError" class="text-danger"></span>
							<input type="hidden" id="id">
							<button type="submit" id="Addbtn" onclick="addData()" name="submitc"><i class="fa fa-plus-square" style="font-size:24px"></i></button>
							<button type="submit" id="updatebtn" onclick="updateData()"><i class="	fa fa-level-down" style="font-size:24px"></i></button>
							<!-- <input type="submit"> -->
							<!-- </form> -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="exampleInputEmail1">Heading</label>
						<input type="test" class="form-control" id="custheading"> <span id="headError" class="text-danger"></span>
					</div>
					<div class="form-group">
						<label for="exampleInputEmail1">Date:</label>
						<input type="datetime-local" class="form-control" id="custdate"> <span id="dateError" class="text-danger"></span>
					</div>
					<input type="hidden" id="id">
					<button type="submit" class="btn btn-primary" id="addfolloebtn" onclick="addfollowData()">Submit</button>
					<button type="submit" class="btn btn-primary" id="updatefollowbtn" onclick="updatefollowData()">Update</button>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<!-- modal -->
    	<!-- Modal -->
	<div class="modal fade" id="custexampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="name">Name</label>
						<input type="text" class="form-control" id="namecust"> <span id="nameError" class="text-danger"></span>
					</div>
                    <div class="form-group">
						<label for="bname">Business Name</label>
						<input type="text" class="form-control" id="bnamecust"> <span id="bnameError" class="text-danger"></span>
					</div>
                    <div class="form-group">
						<label for="email">Email</label>
						<input type="email" class="form-control" id="emailcust"> <span id="emailError" class="text-danger"></span>
					</div>
                    <div class="form-group">
						<label for="location">Location</label>
						<input type="text" class="form-control" id="loccust"> <span id="locError" class="text-danger"></span>
					</div>
					<div class="form-group">
						<label for="date">Update Date:</label>
						<input type="datetime-local" class="form-control" id="custdate"> <span id="dateError" class="text-danger"></span>
					</div>
					<input type="hidden" id="id">
					<button type="submit" class="btn btn-primary" id="addcustbtn" onclick="addcustData()">Submit</button>
					<button type="submit" class="btn btn-primary" id="updatecustbtn" onclick="updatecustData()">Update</button>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<!-- modal -->
	<script>
		$("#Addbtn").show();
		$("#updatebtn").hide();
		$("#addfolloebtn").show();
		$("#updatefollowbtn").hide();
        $("#addcustbtn").show();
        $("#updatecustbtn").hide();
		$.ajaxSetup({
		            headers: {
		                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		            }
		        });
		// fetch data
		function allData(){
		    $.ajax({
		        type: "GET",
		        dataType:'json',
		        url:"/comments/all",
		        success:function(response){
		        //  console.log(data);
		        var data="";
		        $.each(response, function(key, value){
		            // console.log(value);
		            data = data + "<li>";
		            data = data + "<h6>"+value.comment+"</h6>";
		            data = data + "<p>Date: "+value.date+" <a onclick='editData("+value.id+")'><i class='fa fa-edit' style='font-size:24px'> </i></a><a onclick='deleteData("+value.id+")'><i class='fa fa-trash-o' style='font-size:24px'></i></a></p>";
		            data = data + "</li>";
		        })
		        $('#addcom').html(data);
		        }
		    })
		}
		allData();
		// clear data
		function clearData(){
		    $("#comment").val();
		}
		/**add data* */
		function addData(){
		   var comment= $("#comment").val();
		//    console.log(comment);
		$.ajax({
		    type:"POST",
		    dataType:"json",
		    data:{comment:comment},
		    url: "/comment/store/",
		    success:function(data){
		        clearData();
		        allData();
		        swal({
		  title: "Good job!",
		  toast:true,
		  text: "Data inserted successfully!",
		  icon: "success",
		});
		        // console.log("sucessfully inserted");
		    },
		    error:function(error){
		    $("#comError").text(error.responseJSON.errors.comment);
		    }
		})
		}
		// -------------------start edit data--------
		function editData(id){
		// alert();
		$.ajax({
		    type:"GET",
		    dataType: "json",
		    url: "/comment/edit/"+id,
		    success: function(data){
		       $("#Addbtn").hide();
		        $("#updatebtn").show();

		        $("#id").val(data.id);
		        $("#comment").val(data.comment);
		    }
		})
		}
		// -----------------end edit data---------
		// -----------------start update data---------
		function updateData(){
		    var id= $("#id").val();
		    var comment= $("#comment").val();

		    $.ajax({
		        type:"POST",
		        dataType:"json",
		        data:{comment:comment},
		        url:"/comment/update/"+id,
		        success:function(data){
		            $("#Addbtn").show();
		        $("#updatebtn").hide();
		            clearData();
		        allData();
		        },
		        error:function(error){
		    $("#comError").text(error.responseJSON.errors.comment);
		    }
		    })
		}
		// -----------------end update data---------
		//=======================delete data
		function deleteData(id){
		    swal({
		  title: "Are you sure?",
		  text: "Once deleted, you will not be able to recover this imaginary file!",
		  icon: "warning",
		  buttons: true,
		  dangerMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
		    $.ajax({
		        type:"GET",
		        dataType:"json",
		        url:"/comment/destroy/"+id,
		        success:function(data){
		            clearData();
		        allData();
		            $("#Addbtn").show();
		        $("#updatebtn").hide();

		        }
		    })
		  } else {
		    swal("cancle!");
		  }
		  clearData();
		        allData();
		});

		}
		// --------------end delete data

		// // fetch followup data
		function followallData(){
		    $.ajax({
		        type: "GET",
		        dataType:'json',
		        url:"/followup/all",
		        success:function(response){
		        //  console.log(data);
		        var data="";
		        $.each(response, function(key, value){
		            console.log(value);
		            data = data + "<tr>";
		            data = data + "<td>";
		            data = data + "<h5>"+value.title_followup+"</h5>";
		            data = data + "<p>"+value.Date+"</p>";
		            data = data + "<td>";
		            data = data + "<a data-toggle='modal' data-target='#exampleModal' onclick='editfollowupData("+value.id+")'><i class='fa fa-edit' style='font-size:24px'></i></a> ";
		            data = data + " <a onclick='deletefollowData("+value.id+")'><i class='fa fa-trash-o' style='font-size:24px'></i></a>";
		            data = data + "</td>";
		            data = data + "</tr>";
		        })
		        $('tbody').html(data);
		        }
		    })
		}
		followallData();
		// clear data
		function clearfollowData(){
		    $("#custheading").val();
		    $("#custdate").val();
		}
		/**add data* */
		function addfollowData(){
		   var title_followup= $("#custheading").val();
		   var Date= $("#custdate").val();

		//    console.log(comment);
		$.ajax({
		    type:"POST",
		    dataType:"json",
		    data:{title_followup:title_followup,Date:Date},
		    url: "/followup/store/",
		    success:function(data){
		        clearfollowData();
		        followallData();
		        swal({
		  title: "Good job!",
		  toast:true,
		  text: "Data inserted successfully!",
		  icon: "success",
		});
		        // console.log("sucessfully inserted");
		    },
		    error:function(error){
		    $("#headError").text(error.responseJSON.errors.title_followup);
		    $("#dateError").text(error.responseJSON.errors.Date);
		    }
		})
		}
		// -------------------start edit data--------
		function editfollowupData(id){
		// alert();
		$.ajax({
		    type:"GET",
		    dataType: "json",
		    url: "/followup/edit/"+id,
		    success: function(data){
		        $("#addfolloebtn").hide();
		        $("#updatefollowbtn").show();

		        $("#id").val(data.id);
		        $("#custheading").val(data.title_followup);
		        $("#custdate").val(data.Date);
		    }
		})
		}
		// -----------------end edit data---------
		function updatefollowData(){
		    var id= $("#id").val();
		    var title_followup= $("#custheading").val();
		    var Date= $("#custdate").val();

		    $.ajax({
		        type:"POST",
		        dataType:"json",
		        data:{title_followup:title_followup,Date:Date},
		        url:"/followup/update/"+id,
		        success:function(data){
		            clearfollowData();
		        followallData();
		            $("#addfolloebtn").hide();
		        $("#updatefollowbtn").show();

		        },
		        error:function(error){
		     $("#headError").text(error.responseJSON.errors.title_followup);
		    $("#dateError").text(error.responseJSON.errors.Date);

		    }
		    })
		}
		// -----------------end update data---------

		//=======================delete data
		function deletefollowData(id){
		    swal({
		  title: "Are you sure?",
		  text: "Once deleted, you will not be able to recover this imaginary file!",
		  icon: "warning",
		  buttons: true,
		  dangerMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
		    $.ajax({
		        type:"GET",
		        dataType:"json",
		        url:"/followup/destroy/"+id,
		        success:function(data){
		            clearfollowData();
		        followallData();
		                $("#addfolloebtn").show();
		        $("#updatefollowbtn").hide();

		        }
		    })
		  } else {
		    swal("cancle!");
		  }
		  clearfollowData();
		        followallData();
		});

		}
		// --------------end delete data
        /*****For customer*****/
        // // fetch followup data
		function customerData(){
		    $.ajax({
		        type: "GET",
		        dataType:'json',
		        url:"/customer/all",
		        success:function(response){
		        //  console.log(data);
		        var data="";
		        $.each(response, function(key, value){
		            console.log(value);
		            data = data + "<div class='row'>";
		            data = data + "<div class='col-md-4'>";
		            data = data + "<h6>"+value.full_name+"</h6>";
		            data = data + "<h6>"+value.business_name+"</h6>";
		            data = data + "</div>";
		            data = data + "<div class='col-md-8'>";
		            data = data + "<a data-toggle='modal' data-target='#custexampleModal' onclick='editcustData("+value.id+")'><i class='fa fa-edit' style='font-size:24px'></i> </a>";
                    data = data + " <a onclick='deletecustData("+value.id+")'> <i class='fa fa-trash-o' style='font-size:24px'></i></a>";
		            data = data + "</div>";
		            data = data + "</div>";
                    data = data + "<p>Email :"+value.email+"</p>";
                    data = data + "<p>Location:"+value.address+"Last Update: "+value.updated_at+"</p>";
		        })
		        $('.customer').html(data);
		        }
		    })
		}

		customerData();
		// clear data
		function clearcustData(){
		    $("#namecust").val();
		    $("#bnamecust").val();
            $("#emailcust").val();
            $("#loccust").val();
            $("#custdate").val();
		}
		/**add data* */
		function addcustData(){
		   var full_name= $("#namecust").val();
		   var business_name= $("#bnamecust").val();
           var email= $("#emailcust").val();
           var address= $("#loccust").val();
           var updated_at= $("#custdate").val();

		//    console.log(comment);
		$.ajax({
		    type:"POST",
		    dataType:"json",
		    data:{full_name:full_name,business_name:business_name,email:email,address:address,updated_at:updated_at},
		    url: "/customer/store/",
		    success:function(data){
		        clearcustData();
		        customerData();
		        swal({
		  title: "Good job!",
		  toast:true,
		  text: "Data inserted successfully!",
		  icon: "success",
		});
		        // console.log("sucessfully inserted");
		    },
		    error:function(error){
		    $("#nameError").text(error.responseJSON.errors.full_name);
		    $("#bnameError").text(error.responseJSON.errors.business_name);
            $("#emailError").text(error.responseJSON.errors.email);
		    $("#locError").text(error.responseJSON.errors.address);
		    }
		})
		}
		// -------------------start edit data--------
		function editcustData(id){
		// alert();
		$.ajax({
		    type:"GET",
		    dataType: "json",
		    url: "/customer/edit/"+id,
		    success: function(data){
                $("#addcustbtn").hide();
        $("#updatecustbtn").show();
		        $("#id").val(data.id);
		        $("#namecust").val(data.full_name);
		        $("#bnamecust").val(data.business_name);
                $("#emailcust").val(data.email);
                $("#loccust").val(data.address);
                $("#custdate").val(data.updated_at);
		    }
		})
		}
		// -----------------end edit data---------
		function updatecustData(){
		    var id= $("#id").val();
		    var full_name= $("#namecust").val();
		    var business_name= $("#bnamecust").val();
		    var email= $("#emailcust").val();
		    var address= $("#loccust").val();
            var updated_at= $("#custdate").val();

		    $.ajax({
		        type:"POST",
		        dataType:"json",
		        data:{full_name:full_name,business_name:business_name,email:email,address:address,updated_at:updated_at},
		        url:"/customer/update/"+id,
		        success:function(data){
		            clearcustData();
		        customerData();
                $("#addcustbtn").hide();
                $("#updatecustbtn").show();
		        },
		        error:function(error){
                    $("#nameError").text(error.responseJSON.errors.full_name);
		    $("#bnameError").text(error.responseJSON.errors.business_name);
            $("#emailError").text(error.responseJSON.errors.email);
		    $("#locError").text(error.responseJSON.errors.address);
		    }
		    })
		}
		// -----------------end update data---------

		//=======================delete data
		function deletecustData(id){
		    swal({
		  title: "Are you sure?",
		  text: "Once deleted, you will not be able to recover this imaginary file!",
		  icon: "warning",
		  buttons: true,
		  dangerMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
		    $.ajax({
		        type:"GET",
		        dataType:"json",
		        url:"/customer/destroy/"+id,
		        success:function(data){
		            clearcustData();
		        customerData();
                $("#addcustbtn").show();
                $("#updatecustbtn").hide();

		        }
		    })
		  } else {
		    swal("cancle!");
		  }
		  clearcustData();
		        customerData();
		});

		}
		// --------------end delete data
	</script>
</body>

</html>
<?php /**PATH D:\laravel\wireframe\resources\views/wel.blade.php ENDPATH**/ ?>