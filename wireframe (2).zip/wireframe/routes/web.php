<?php
use App\Http\Controllers\CommentController;
use App\Http\Controllers\FollowupController;
use App\Http\Controllers\CustomerController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});
Route::get('test', function () {
    return view('text');
});*/
Route::get('/','App\Http\Controllers\FollowupController@show');
Route::get('followup_delete/{id}','App\Http\Controllers\FollowupController@destroy');
Route::get('followup_create','App\Http\Controllers\FollowupController@create');
Route::post('followup_submit','App\Http\Controllers\FollowupController@store');
Route::get('followup_edit/{id}','App\Http\Controllers\FollowupController@edit');
Route::post('followup_update/{id}','App\Http\Controllers\FollowupController@update')->name('followup.update');
// for customer
Route::post('/',[CommentController::class,'store']);
// Route::get('/crud',[CommentController::class,'show']);
Route::get('/crud','App\Http\Controllers\CommentController@show');
// Route::view('/cust','customers');

Route::get('/cust', function () {
    return view('customers');
});
Route::view('index','wel');
Route::get('/comments/all',[CommentController::class,'allData']);
Route::post('/comment/store/',[CommentController::class,'storeData']);
Route::get('/comment/edit/{id}',[CommentController::class,'editData']);
Route::post('/comment/update/{id}',[CommentController::class,'updateData']);
Route::get('/comment/destroy/{id}',[CommentController::class,'deleteData']);

// followup

Route::get('/followup/all',[FollowupController::class,'followallData']);
Route::post('/followup/store/',[FollowupController::class,'storeData']);
Route::get('/followup/edit/{id}',[FollowupController::class,'editfollowupData']);
Route::post('/followup/update/{id}',[FollowupController::class,'updatefollowData']);
Route::get('/followup/destroy/{id}',[FollowupController::class,'deletefollowData']);

// For Customer

Route::get('/customer/all',[CustomerController::class,'customerData']);
Route::post('/customer/store/',[CustomerController::class,'storeData']);
Route::get('/customer/edit/{id}',[CustomerController::class,'editcustData']);
Route::post('/customer/update/{id}',[CustomerController::class,'updatecustData']);
Route::get('/customer/destroy/{id}',[CustomerController::class,'deletecustData']);
