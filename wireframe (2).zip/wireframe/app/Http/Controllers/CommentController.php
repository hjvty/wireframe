<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{

    // all data fetch
  public function allData(){
      $data = Comment::orderBy('id','DESC')->get();
      return response()->json($data);
  }
//   store data
  public function storeData(Request $request){
      $request->validate([
          'comment' => 'required',
      ]);
     $data=Comment::insert([
         'comment' => $request->comment,

     ]);
     return response()->json($data);
  }

//   ------------edit comment
public function editData($id){
    $data = Comment::findOrFail($id);
    return response()->json($data);
}
//-------------end edit comment
// -------------------update comment
public function updateData(Request $request, $id){
    $request->validate([
        'comment' => 'required',
    ]);
    $data = Comment::findOrFail($id)->update([
        'comment'=>$request->comment,
    ]);
    return response()->json($data);
}
// -------------end update comment
// ***************delete
public function deleteData($id){
     Comment::where('id', $id)->firstorfail()->delete();
}
// end delete*************

}
