<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
class CustomerController extends Controller
{
        // all data fetch
        public function customerData(){
            $data = Customer::orderBy('id','DESC')->get();
            return response()->json($data);
        }


        //   store data
      public function storeData(Request $request){
        $request->validate([
            'full_name' => 'required',
            'business_name'=>'required',
            'email'=>'required',
            'address'=>'required',
        ]);
       $data=Customer::insert([
           'full_name' => $request->full_name,
           'business_name' => $request->business_name,
           'email' => $request->email,
           'address' => $request->address,

       ]);
       return response()->json($data);
    }
    //   ------------edit comment
    public function editcustData($id){
        $data = Customer::findOrFail($id);
        return response()->json($data);
    }
    //-------------end edit comment
    // -------------------update comment
    public function updatecustData(Request $request, $id){
        $request->validate([
            'full_name' => 'required',
            'business_name'=>'required',
            'email'=>'required',
            'address'=>'required',
                    ]);
        $data = Customer::findOrFail($id)->update([
            'full_name' => $request->full_name,
           'business_name' => $request->business_name,
           'email' => $request->email,
           'address' => $request->address,

        ]);
        return response()->json($data);
    }
    // -------------end update comment
    // ***************delete
    public function deletecustData($id){
        Customer::where('id', $id)->firstorfail()->delete();
    }
    // end delete*************

}
