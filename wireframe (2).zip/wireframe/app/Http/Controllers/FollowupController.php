<?php

namespace App\Http\Controllers;

use App\Models\Followup;
use Illuminate\Http\Request;

class FollowupController extends Controller
{

    // all data fetch
    public function followallData(){
        $data = Followup::orderBy('id','DESC')->get();
        return response()->json($data);
    }


    //   store data
  public function storeData(Request $request){
    $request->validate([
        'title_followup' => 'required',
        'Date' => 'required',
    ]);
   $data=Followup::insert([
       'title_followup' => $request->title_followup,
       'Date'=>$request->Date,


   ]);
   return response()->json($data);
}
//   ------------edit comment
public function editfollowupData($id){
    $data = Followup::findOrFail($id);
    return response()->json($data);
}
//-------------end edit comment
// -------------------update comment
public function updatefollowData(Request $request, $id){
    $request->validate([
        'title_followup' => 'required',
        'Date' => 'required',
    ]);
    $data = Followup::findOrFail($id)->update([
        'title_followup'=>$request->title_followup,
        'Date'=>$request->Date,
    ]);
    return response()->json($data);
}
// -------------end update comment
// ***************delete
public function deletefollowData($id){
    Followup::where('id', $id)->firstorfail()->delete();
}
// end delete*************

}
