@extends('wel')
@section('cards')
<div class="card-body">
				<div class="row">
					<div class="col-md-2">
						<img src="{{ url('public/assets/Spark-Joy-at-Work.jpg') }}" alt="customer">
					</div>
					<div class="col-md-10">
						<div>
							<div class="row">
								<div class="col-md-4">

									<h4>Customer Name
                    </h4>
									<h4>Business Name
                    </h4>
								</div>
								<div class="cpl-md-8"> <a href="#">edit
                    </a>
									<a href="#">delete
                    </a>
								</div>
							</div>
							<p>Email : xyz@gmail.com Phone:-9455</p>
							<p>Location: gcg Last Update:23588</p>
						</div>
					</div>
				</div>
			</div>
@endsection
