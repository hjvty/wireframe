<!DOCTYPE html>
<html lang="en">

<head>
	<title>Wireframe</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
	</script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
	</script>
	<style>
		.table td, .table th {
		    border-bottom: 1px solid #dee2e6;
		}


	</style>
</head>

<body style="background-color:#f1f1f1">
	<div class="container">
		<br>
		<div class="card mt-6">
			<div class="card-body">
				<div class="row">
                <a href="/" class="btn btn-secondary">Back</a>
					<div class="col-md-12">
                      <form action="{{route('followup.update',[$followArr->id])}}" method="post">
                      @csrf
                      <div class="form-group">
                       <label for="exampleInputEmail1">Followup title</label>
                       <input type="text" class="form-control" name="followuptitle" id="followuptitle" value="{{$followArr->title_followup}}" required/>
                      </div>
                      <div class="form-group">
                       <label for="exampleInputEmail1">Date</label>
                       <input type="date" class="form-control" name="followupdate" id="followupdate" value="{{$followArr->Date}}" >
                      </div>

                      <button type="submit" class="btn btn-primary">Submit</button>
                      </form>
                    </div>
				</div>
			</div>
		</div>
		<br>

	</div>
</body>

</html>
