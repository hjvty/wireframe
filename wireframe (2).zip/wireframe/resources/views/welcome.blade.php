<!DOCTYPE html>
<html lang="en">

<head>
	<title>Wireframe</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
	</script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js">
	</script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<style>
		.table td, .table th {
		    border-bottom: 1px solid #dee2e6;
		}


	</style>
</head>

<body style="background-color:#f1f1f1">
	<div class="container">
		<br>
		<div class="card mt-6">
        <div class="card-body">
				<div class="row">
					<div class="col-md-2">
						<img src="{{ url('public/assets/Spark-Joy-at-Work.jpg') }}" alt="customer">
					</div>
					<div class="col-md-10">
						<div>
							<div class="row">
								<div class="col-md-4">

									<h4>Customer Name
                    </h4>
									<h4>Business Name
                    </h4>
								</div>
								<div class="cpl-md-8"> <a href="#">edit
                    </a>
									<a href="#">delete
                    </a>
								</div>
							</div>
							<p>Email : xyz@gmail.com Phone:-9455</p>
							<p>Location: gcg Last Update:23588</p>
						</div>
					</div>
				</div>
			</div>

		</div>
		<br>
		<div class="row mt-4">
			<div class="col-md-8" style="">
              <div class="card-deck">
					<div class="card">
						<div class="card-body">
				<!-- Nav tabs -->
				<ul class="nav nav-tabs">
					<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#followup">Follow Up</a>
					</li>
					<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#drive">Drive</a>
					</li>
				</ul>
				<!-- Tab panes -->
				<div class="tab-content">
					<div id="followup" class="container tab-pane active">
						<br>
						<div class="panel-body">
                        {{session('msg')}}
                               <a href="followup_create" class="btn btn-success float-right mb-3">Add</a>
							<table class="table table-hover">
								<tbody>
                                @foreach($followArr as $followup)
									<tr>
										<td>
											<h5>{{$followup->title_followup}}</h5>
											<p>date: {{$followup->Date}}</p>
										</td>
										<td>
											<a class="btn btn-primary" href="followup_edit/{{$followup->id}}">Edit</a>
											<a class="btn btn-danger" href="followup_delete/{{$followup->id}}">Delete</a>
										</td>
									</tr>
                                @endforeach

									<tr></tr>
								</tbody>
							</table>
						</div>
					</div>
					<div id="drive" class="container tab-pane fade">
						<br>
						<h3>Menu 1</h3>
						<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					</div>
				</div>
                </div>
                </div>
                </div>
			</div>
			<div class="col-md-4" style="display: inline-grid;">
				<div class="card-deck">
					<div class="card">
						<div class="card-body">
							<h5>Add Comments</h5>
                            <ul class="mt-5" id="addcom" style="list-style: none;">
                            <!-- <li><h6>lknkj</h6><p>date:6/5/21
                            <a href="#" data-toggle="modal" data-target="#exampleModal">edit</a>
                            <a href="#">delete</a></p></li> -->
                         </ul>
                            <form id="Addfrom" name="userForm" class="ml-5">
                            @csrf
                            <input type="text" name="comment" id="comment" required/>
                            <span id="comError" class="alert-message"></span>
                             <button type="submit" id="frmsubmit" name="submitc">Add</button>
                             <!-- <input type="submit"> -->
                            </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

    <!-- modal -->
    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form id="editcmnt">

  <div class="form-group">
    <label for="exampleInputEmail1">Add Comment</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="comments">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
    <!-- End modal -->

  <script type="text/javascript">
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

function viewData(){
    jQuery.ajax({
        type:'GET',
         dataType:"json",
         url:"/crud",
         success:function(result){
            var rows="";
            jQuery.each(result, function(key, value){
                rows=rows + "<li>";
                rows=rows + "<h6>"+value.comment+"</h6><p>date:"+value.date+"<a href='#' data-toggle='modal' data-target='#exampleModal'>edit</a> <a href='#'>delete</a></p>";
                rows=rows + "</li>";
              });
            $('#addcom').html(rows);
         }
    })
}
viewData();
  jQuery('#Addfrom').submit(function(e) {
     e.preventDefault();
     jQuery.ajax({
         url:"{{url('/')}}",
         data:jQuery('#Addfrom').serialize(),
         type:'post',
         success:function(result){
            //  console.log(result);
            jQuery('#Addfrom')['0'].reset();
            // fetchComm();
         }
     });
  });


  </script>
</body>

</html>
